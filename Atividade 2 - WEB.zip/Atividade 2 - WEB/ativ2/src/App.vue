<template>
  <div id="app">
    <InpTodo></InpTodo>
    <TableTodo></TableTodo>
  </div>
</template>

<script>
import TableTodo from './components/TableTodo.vue'
import InpTodo from './components/InpTodo.vue'
export default {
  name: 'App',
  components: {
    InpTodo,
    TableTodo
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
