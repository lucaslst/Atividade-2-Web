<template>
<div>
  <label>Name:</label>
  <input v-model="name" type="text" name="name"/><br>
  <label>e-mail:</label>
  <input v-model="email" type="email" name="email"/><br>
  <label>Date of birth:</label>
  <input v-model="datebirth" type="date" name="datebirth"/><br>
  <label for="services">Services:</label>

  <div id= "checkbox">
         <input v-model="checkbox"  type="checkbox" name= "checkbox"  class= "processInput" id="Processing - 1 micro - $ 1,00 per hour" value="1.0" @click="check($event)">
         <label class= "processLabel"> Processing - 1 micro - $ 1,00 per hour</label>
         <input v-model="checkbox" type="checkbox" name= "checkbox" class= "storageInput" id="Storage - 10 GB HD - $ 0,5 per hour" value="0.5" @click="check($event)">
         <label class= "storageLabel"> Storage - 10 GB HD - $ 0,5 per hour</label><br>
         <input v-model="checkbox" type="checkbox" name= "checkbox" class= "processInput" id="Processing - 1 medium - $ 2,00 per hour" value="2.0" @click="check($event)">
         <label class= "processLabel"> Processing - 1 medium - $ 2,00 per hour</label>
         <input v-model="checkbox" type="checkbox" name= "checkbox" class= "storageInput" id="Storage - 1 TB HD - $ 1,00 per hour" value="1.0" @click="check($event)">
         <label class= "storageLabel"> Storage - 1 TB HD - $ 1,00 per hour</label><br>
         <input v-model="checkbox" type="checkbox" name= "checkbox" class= "processInput" id="Processing - 1 large - $ 10,00 per hour" value="10.0" @click="check($event)">
         <label class= "processLabel"> Processing - 1 large - $ 10,00 per hour</label>
         <input v-model="checkbox" type="checkbox" name= "checkbox" class= "storageInput" id="Storage - 100 GB SSD - $ 5,00 per hour" value="5.0" @click="check($event)">
         <label class= "storageLabel"> Storage - 100 GB SSD - $ 5,00 per hour</label><br>
      </div>
        <div id="buttons">
          <button class="botao" type= "reset" value="CLEAR"> 
          <button class= "botao" type= "button" @click = "inserirDadosTabela()" value="ADD">
        </div>
</div>
</template>

<script>
export default {
    name: "InpTodo",
    props: {},
    data: {
      name: "",
      email: "",
      datebirth: "",
      services: [],
      soma: ""
    },
    methods: {
      add: function() {
        var date = this.date;
        var ano_atual = new Date().getFullYear();
        var ano_informado = date.split('/')[2];
        if(ano_atual - ano_informado >= 18){
          let inputs = {}
          inputs.name = this.name;
          inputs.datebirth = this.datebirth;
          inputs.services = this.services;
          inputs.soma = this.soma;
        }
      },

      clear: function(){
        
      }

    }
}

</script>

<style>

</style>