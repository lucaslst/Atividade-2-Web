<template>
   <table id = "tabela" class= "tabela" border = "1">
    <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">E-mail</th>
          <th scope="col">Date of Birth</th>
          <th scope="col">Services</th>
          <th scope="col">Total</th>
        </tr>
    </thead>
    <tbody>
        <tr v-for="(todo) in todos" v-bind:key="todo">
            <td>
                <span>{{ todo.name }} </span>
            </td>
            <td>
                <span>{{ todo.email }} </span>
            </td>
            <td>
                <span>{{ todo.datebirth }} </span>
            </td>
            <td>
                <span>{{ todo.services }} </span>
            </td>
            <td>
                <span>{{ todo.soma }} </span>
            </td>
        </tr>
    </tbody>
</table>

</template>

<script>
export default {
    name: "TableTodo",
    prop: ["todos"]
}
</script>

<style>

</style>